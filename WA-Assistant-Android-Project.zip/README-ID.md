# WA Assistant — Android project

Project Android native sederhana untuk dashboard aktivitas WhatsApp dengan verifikasi manual.

## Fitur
- Dashboard dark mode
- Input daftar nomor (satu nomor per baris)
- Tombol START / STOP untuk sesi pencatatan manual
- Membuka aplikasi WhatsApp resmi
- Izin dan floating status window
- Pengaturan Accessibility Android (shortcut ke halaman pengaturan)
- Getaran tes dan riwayat aktivitas

## Batasan keamanan
Aplikasi ini tidak meminta OTP, membaca SMS/OTP, mengulang permintaan kode, atau mengotomatisasi verifikasi WhatsApp. Pengguna melakukan verifikasi sendiri di aplikasi WhatsApp resmi.

## Build APK melalui GitHub Actions
1. Buat repository GitHub baru bernama `wa-assistant`.
2. Ekstrak semua isi ZIP ini, lalu upload seluruh file dan folder ke repository (isi folder project, bukan folder induknya).
3. Pastikan file `.github/workflows/build.yml` ikut ter-upload.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build WA Assistant APK**, lalu tekan **Run workflow** bila belum berjalan otomatis.
6. Setelah status build selesai, buka hasil run dan unduh artifact **WA-Assistant-APK**.
7. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`, lalu instal di Android.

## Persyaratan
- Android Studio/Gradle 8.9 untuk build lokal, atau GitHub Actions seperti langkah di atas.
- JDK 17.
