package com.example.waassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var numbers: EditText
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var history: TextView
    private var running = false
    private var processed = 0

    private val bg = Color.rgb(13, 19, 32)
    private val panel = Color.rgb(27, 38, 56)
    private val white = Color.WHITE
    private val muted = Color.rgb(166, 180, 199)
    private val green = Color.rgb(28, 176, 111)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "WA ASSISTANT"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)
        page.addView(label("Asisten aktivitas WhatsApp • Mode manual", muted, 13f))
        page.addView(space(22))

        val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statRow.addView(statCard("NOMOR", "0"), LinearLayout.LayoutParams(0, dp(86), 1f))
        statRow.addView(spaceWidth(10))
        statRow.addView(statCard("SELESAI", "0"), LinearLayout.LayoutParams(0, dp(86), 1f))
        page.addView(statRow)
        count = label("0 nomor dimasukkan", muted, 13f)
        page.addView(count)
        page.addView(space(20))

        page.addView(label("DAFTAR NOMOR", white, 16f, true))
        numbers = EditText(this).apply {
            hint = "62812xxxxxxxx\n62813xxxxxxxx"
            setHintTextColor(Color.rgb(120, 135, 155))
            setTextColor(white)
            textSize = 15f
            gravity = Gravity.TOP
            minLines = 4
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        page.addView(numbers, LinearLayout.LayoutParams(-1, dp(135)))
        page.addView(label("Masukkan nomor milik sendiri, satu nomor per baris.", muted, 12f))
        page.addView(space(16))

        status = label("Status: Siap", green, 14f, true)
        page.addView(status)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("START", green) { startSession() }, LinearLayout.LayoutParams(0, dp(50), 1f))
        actions.addView(spaceWidth(10))
        actions.addView(actionButton("STOP", Color.rgb(70, 83, 103)) { stopSession() }, LinearLayout.LayoutParams(0, dp(50), 1f))
        page.addView(actions)
        page.addView(space(10))
        page.addView(actionButton("BUKA WHATSAPP", Color.rgb(37, 91, 150)) { openWhatsApp() })
        page.addView(space(20))

        page.addView(label("TOOLS", white, 16f, true))
        page.addView(space(8))
        page.addView(actionButton("IZIN FLOATING WINDOW", panel) { requestOverlay() })
        page.addView(space(8))
        page.addView(actionButton("PENGATURAN AKSESIBILITAS", panel) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        page.addView(space(8))
        page.addView(actionButton("AKTIFKAN FLOATING STATUS", panel) { startFloating() })
        page.addView(space(8))
        page.addView(actionButton("GETAR / TES NOTIFIKASI", panel) { vibrate() })
        page.addView(space(20))

        page.addView(label("RIWAYAT AKTIVITAS", white, 16f, true))
        history = label("Belum ada aktivitas.", muted, 13f)
        val historyPanel = LinearLayout(this).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            addView(history)
        }
        page.addView(historyPanel)
        page.addView(space(16))
        page.addView(label("Catatan: aplikasi ini tidak membaca OTP, tidak meminta kode berulang, dan tidak mengendalikan proses verifikasi WhatsApp. Verifikasi dilakukan sendiri di WhatsApp resmi.", muted, 12f))
    }

    private fun startSession() {
        val list = numbers.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (list.isEmpty()) {
            Toast.makeText(this, "Masukkan minimal satu nomor.", Toast.LENGTH_SHORT).show()
            return
        }
        running = true
        count.text = "${list.size} nomor dimasukkan"
        status.text = "Status: Sesi dimulai • verifikasi manual"
        addHistory("Sesi dimulai dengan ${list.size} nomor.")
        vibrate()
    }

    private fun stopSession() {
        running = false
        status.text = "Status: Dihentikan"
        addHistory("Sesi dihentikan.")
    }

    private fun openWhatsApp() {
        val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "WhatsApp tidak ditemukan. Silakan instal WhatsApp resmi.", Toast.LENGTH_LONG).show()
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            Toast.makeText(this, "Izin floating window sudah aktif.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFloating() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            requestOverlay()
            return
        }
        startService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Floating status diaktifkan.", Toast.LENGTH_SHORT).show()
    }

    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(220, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vibrator.vibrate(220)
    }

    private fun addHistory(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        history.text = "$time  •  $message\n" + history.text
    }

    private fun statCard(name: String, value: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
            addView(label(value, white, 24f, true))
            addView(label(name, muted, 11f))
        }
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit): View {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(color)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(48))
        }
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceWidth(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
